import React from 'react'

export default function Nav() {
  return (
    <nav>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </nav>
  )
}
